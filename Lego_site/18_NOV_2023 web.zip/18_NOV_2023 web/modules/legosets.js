const Set = require('../data/setData');
const Theme = require('../data/themeData');
require('dotenv').config();
const Sequelize = require('sequelize');


// set up sequelize to point to our postgres database
let sequelize = new Sequelize(process.env.DB_DATABASE, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
      ssl: { rejectUnauthorized: false },
    },
  });
  
sequelize
.authenticate()
.then(() => {
    console.log('Connection has been established successfully.');
})
.catch((err) => {
    console.log('Unable to connect to the database:', err);
});


let legoSets = [];

const initialize = async () => {
    try {
        await sequelize.sync();
        console.log('Database synced successfully.');
    } catch (error) {
        throw new Error(`Database sync error: ${error}`);
    }
};
  

// Retrieve all available sets
const getAllSets = async () => {
    try {
      const sets = await Set.findAll({ include: [Theme] });
      return sets;
    } catch (error) {
      console.error('Error fetching all sets:', error);
      throw new Error('Unable to fetch sets from the database.');
    }
};

// Retrieve a specific set by its number
const getSetByNum = async (setNum) => {
    try {
      const set = await Set.findOne({
        where: { set_num: setNum },
        include: [Theme],
      });
  
      if (!set) {
        throw new Error('Set not found.');
      }
  
      return set;
    } catch (error) {
      console.error('Error fetching set by number:', error);
      throw new Error('Unable to fetch set from the database.');
    }
};
  
// Retrieve all sets matching a specific theme
const getSetsByTheme = async (theme) => {
try {
    const sets = await Set.findAll({
    include: [Theme],
    where: {
        '$Theme.name$': {
        [Sequelize.Op.iLike]: `%${theme}%`,
        },
    },
    });

    if (sets.length === 0) {
    throw new Error('No sets found for the specified theme.');
    }

    return sets;
} catch (error) {
    console.error('Error fetching sets by theme:', error);
    throw new Error('Unable to fetch sets from the database.');
}
};

// Self-invoking function to initialize data
(async () => {
    try {
        await initialize();
        console.log(await getAllSets()); // Logging all sets after initialization
    } catch (error) {
        console.error('Initialization error:', error);
    }
})();

module.exports = { initialize, getAllSets, getSetByNum, getSetsByTheme };
