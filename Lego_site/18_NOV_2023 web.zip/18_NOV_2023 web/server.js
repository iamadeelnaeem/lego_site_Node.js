/*********************************************************************************
*  BTI325 – Assignment 3
*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
*
*  Name: Aria Shakibai    Student ID: 112070164  Date: 2023-11-03
*
*  Online (Cyclic) URL: https://kind-lion-jacket.cyclic.app
*
********************************************************************************/

// Organized imports
const express = require('express');
const path = require('path');
const legoData = require('./modules/legosets');
const axios = require('axios'); // Import axios for making HTTP requests
const ejs = require('ejs');

const app = express();
const PORT = 3001;

app.use(express.static('public'));

// Separated route handling
const renderHomePage = (req, res) => {
  res.render('home'); // Render the 'home.ejs' template
};

const renderAboutPage = (req, res) => {
  res.render('about'); // Render the 'about.ejs' template
};

const fetchLegoSets = async (req, res) => {
  try {
    const { theme } = req.query;
    const result = theme ? await legoData.getSetsbyTheme(theme) : await legoData.getAllSets();
    res.json(result);
  } catch (err) {
    res.status(404).send(err);
  }
};

const fetchLegoSetByNum = async (req, res) => {
  try {
    const { setNum } = req.params;
    const sets = await legoData.getSetsByNum(setNum);
    res.json(sets);
  } catch (err) {
    res.status(404).send(err);
  }
};

const handleNotFound = (req, res) => {
  res.status(404).render('404'); // Render the '404.ejs' template
};

// Route to fetch a random quote from the Quotable API
app.get('/random-quote', async (req, res) => {
  try {
    const response = await axios.get('https://api.quotable.io/random');
    const randomQuote = response.data;

    // Render an EJS template (e.g., 'quote.ejs') to display the random quote.
    res.render('quote', { quote: randomQuote.content });
  } catch (error) {
    // Handle errors if the API request fails.
    console.error(error);
    res.status(500).send('Error fetching random quote');
  }
});

// Routes
app.get('/', renderHomePage);
app.get('/about', renderAboutPage);
app.get('/lego/sets', fetchLegoSets);
app.get('/lego/sets/:setNum', fetchLegoSetByNum);
app.use(handleNotFound);
app.set('view engine', 'ejs');

// Server initialization
const startServer = async () => {
  await legoData.initialize();
  app.listen(PORT, () => {
    console.log(`Server is up and running on port ${PORT}...`);
  });
};

startServer();
